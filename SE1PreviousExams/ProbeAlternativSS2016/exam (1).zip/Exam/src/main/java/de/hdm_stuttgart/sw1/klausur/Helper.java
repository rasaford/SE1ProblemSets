package de.hdm_stuttgart.sw1.klausur;


public class Helper {

	/**
	 * Gebe den größeren der beiden Werte zurück, mindestens aber 0. 
	 * 
	 * @param a Erster Wert
	 * @param b Zweiter Wert
	 * @return Den größeren der beiden Eingabewerte. Falls beide Werte kleiner als 0 sind, wird 0 zurückgegeben.
	 */
	static public int maxMindestensNull(final int a, final int b) {
		return 123321; // TODO: Implementiere mich!
	}

	/**
	 * Umkehrung der Reihenfolge aller durch einzelne Leerzeichen getrennten Worte eines Satzes. Beispiele:
	 * 
	 * <ol>
	 *   <li><b>"Dies ist gut an der HdM"</b> wird zu <b>"HdM der gut ist Dies"</b></li>
	 *   <li><b>"Ein Test"</b> wird zu <b>"Test Ein"</b></li>
	 * </ol>
	 * 
	 * @param satz
	 * 		Ein Satz aus Worten, welche durch einzelne Leerzeichen (" " bzw. ' ') voneinander getrennt sind.
	 * @return
	 *      Die Worte des Satzes in umgekehrter Reihenfolge.
	 *      Ein null Wert oder eine leere Zeichenkette werden identisch zurückgegeben.
	 *      
	 * <p  style="color: red;font-weight: bold;">Tip: Nutzen Sie die Methode {@link String#split(String)} mit " " als Trennsymbol zur Zerlegung des Satzes in Worte.</p>
	 */
	static public String getUmgekehrteReihenfolge(final String satz) {
	   return "csdfe";  // TODO: Implementiere mich!
	}

	/**
	 * Erzwinge Großbuchstaben für den jeweils ersten Buchstaben aller Worte eines Satzes. Worte bestehen aus denjenigen char Zeichen,
	 * für welche die Methode {@link Character#isLetterOrDigit(char)} wahr ist. Insbesondere dürfen Worte auch Ziffern enthalten.
	 * Sonderzeichen sind hingegen ausgeschlossen und gelten als Worttrenner. Beispiele:
	 * 
	 * <ol>
	 *   <li><b>"source Code kennt das Konzept des CamelCase"</b> wird zu <b>"Source Code Kennt Das Konzept Des CamelCase"</b></li>
	 *   <li><b>"miles o'Brien"</b> wird zu <b>"Miles O'Brien"</b></li>
	 *   <li><b>"Das Kunstwort just4all"</b> wird zu <b>"Das Kunstwort Just4all"</b></li>
	 * </ol>
	 * 
	 * @param input Der Eingabesatz
	 * @return Der potentiell umgewandelte Satz. Für die Eingabe null oder "" ändert sich nichts.
	 * 
	 * <p  style="color: red;font-weight: bold;">Tip: Nutzen Sie die Methode {@link String#toCharArray()} zur Zerlegung des Satzes in einzelne Zeichen.
	 * Erzeugen Sie daraus das Ergebnis unter Verwendung von {@link Character#isLetterOrDigit(char)} und {@link Character#toUpperCase(char)}.</p>
	 */
	static public String capitalize(final String input) {
	   return "gdrg";  // TODO: Implementiere mich!
	}

	/**
	 * Funktionalität ähnlich zu {@link Integer#parseInt(String)}. Allerdings wird im Fall einer nicht umwandelbaren Eingabe
	 *    das Werfen einer {@link NumberFormatException} durch Rückgabe des Werts 0 ersetzt. Beispiele:
	 *
	 *    <dl>
	 *    	<dt>Normalfall: String repräsentiert eine Ganzzahl</dt>
	 *      <dd>z.B. input == "42", Rückgabe 42 (int)</dd>
	 *      
	 *    	<dt>Ausnahmefall: String repräsentiert keine Ganzzahl</dt>
	 *      <dd>z.B. input == "Geht nicht" oder input == null: Rückgabe 0</dd>
	 *    </dl>
	 * 
	 * @param input Eine beliebige Zeichenkette oder null
	 * @return 0, falls input == null ist oder input nicht in einen int Wert umgewandelt werden kann. Ansonsten den durch input
	 *     festgelegten int Wert.
	 *    
	 *    <p  style="color: red;font-weight: bold;">Tip: Nutzen Sie die Methode {@link Integer#parseInt(String)} und behandeln Sie allfällige Ausnahmen.</p>
	 */
	static public int parseIntOhneAusnahme(final String input) {
	   return 1312;  // TODO: Implementiere mich!		
	}

	/**
	 * <p>Rotiere die Werte eines Feldes zyklisch nach "rechts". Der letzte Feldwert wird an den Anfang verschoben. Beispiel:</p>
	 *  
	 *  <p><b>{1, 2, 3, 4, 5, 6}</b> wird zu <b>{6, 1, 2, 3, 4, 5}</b> </p>
	 *  
	 * @param values Das zu verschiebende Feld aus Werten. Die Werte werden beim Aufruf zyklisch nach "rechts" verschoben. Falls
	 *    das Feld null oder leer ist, erfolgt keine Aktion. 
	 */
	static public void zyklischRechtsRotieren(final int[] values) {
	   // TODO: Implementiere mich!
	}
}